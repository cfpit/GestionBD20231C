/*
	Ejercicio sobre triggers

	Crea una base de datos llamada testDisparador que contenga una tabla llamada alumnos 
	con las siguientes columnas.

	Tabla alumnos:
	•	id (entero sin signo)
	•	nombre (cadena de caracteres)
	•	apellido (cadena de caracteres)
	•	nota (número real)

*/

CREATE DATABASE testDisparador;

USE testDisparador;

CREATE TABLE alumnos (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(50) NOT NULL,
  apellido VARCHAR(50) NOT NULL,
  nota FLOAT NOT NULL,
  PRIMARY KEY (id)
);


/*
	Trigger 1: trigger_check_nota_before_insert
	Se ejecuta sobre la tabla alumnos.
	Se ejecuta antes de una operación de inserción.
	Si el nuevo valor de la nota que se quiere insertar es negativo, se guarda como 0.
	Si el nuevo valor de la nota que se quiere insertar es mayor que 10, se guarda como 10.
    Una vez creados los triggers escriba 3 sentencias de inserción y actualización sobre la 
    tabla alumnos y verifica que los triggers se están ejecutando correctamente.
*/

DELIMITER $$
CREATE TRIGGER trigger_check_nota_before_insert BEFORE INSERT ON alumnos
FOR EACH ROW
BEGIN
  IF NEW.nota < 0 THEN
    SET NEW.nota = 0;
  ELSEIF NEW.nota > 10 THEN
    SET NEW.nota = 10;
  END IF;
END$$
DELIMITER ;

INSERT INTO alumnos (nombre, apellido, nota) VALUES ('Juan', 'Pérez', -2.5);

INSERT INTO alumnos (nombre, apellido, nota) VALUES ('María', 'García', 15);

INSERT INTO alumnos (nombre, apellido, nota) VALUES ('Luis', 'Rios', 7);

select * from alumnos;




/*
	Trigger2 : trigger_check_nota_before_update
	Se ejecuta sobre la tabla alumnos.
	Se ejecuta antes de una operación de actualización.
	Si el nuevo valor de la nota que se quiere actualizar es negativo, se guarda como 0.
	Si el nuevo valor de la nota que se quiere actualizar es mayor que 10, se guarda como 10.
	Una vez creados los triggers escriba 3 sentencias de inserción y actualización sobre la 
    tabla alumnos y verifica que los triggers se están ejecutando correctamente.

*/

DELIMITER $$
CREATE TRIGGER trigger_check_nota_before_update BEFORE UPDATE ON alumnos
FOR EACH ROW
BEGIN
  IF NEW.nota < 0 THEN
    SET NEW.nota = 0;
  ELSEIF NEW.nota > 10 THEN
    SET NEW.nota = 10;
  END IF;
END$$
DELIMITER ;

-- 1.Insertar un registro con una nota superior a 10:
INSERT INTO alumnos (nombre, apellido, nota) VALUES ('Pedro', 'González', 15);

-- 2.Actualizar el registro con id=1 para que su nota sea -5:
UPDATE alumnos SET nota = -5 WHERE id = 1;

-- 3.Actualizar el registro con id=2 para que su nota sea 9.5:
UPDATE alumnos SET nota = 9.5 WHERE id = 2;


select * from alumnos;



