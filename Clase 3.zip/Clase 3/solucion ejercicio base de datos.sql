-- Creacion de BD y tablas

create database tiendaOnline;

use tiendaOnline;

CREATE TABLE Clientes (
id_cliente INT PRIMARY KEY,
nombre_cliente VARCHAR(255),
correo_electronico VARCHAR(255)
);

CREATE TABLE Productos (
id_producto INT PRIMARY KEY,
nombre_producto VARCHAR(255),
precio_unitario DECIMAL(10,2)
);

CREATE TABLE Ordenes (
id_orden INT PRIMARY KEY,
fecha_orden DATE,
id_cliente INT,
FOREIGN KEY(id_cliente) REFERENCES Clientes(id_cliente)
);

CREATE TABLE DetalleOrden (
id_detalle INT PRIMARY KEY,
id_orden INT,
id_producto INT,
cantidad INT,
FOREIGN KEY (id_orden) REFERENCES Ordenes(id_orden),
FOREIGN KEY (id_producto) REFERENCES Productos(id_producto)
);

-- insercion de registros
-- Inserción de registros en la tabla Clientes
INSERT INTO Clientes (id_cliente, nombre_cliente, correo_electronico)
VALUES
(1, 'Juan Pérez', 'juan.perez@example.com'),
(2, 'María González', 'maria.gonzalez@example.com'),
(3, 'Pedro Ramírez', 'pedro.ramirez@example.com'),
(4, 'Ana Gómez', 'ana.gomez@example.com');

-- Inserción de registros en la tabla Productos
INSERT INTO Productos (id_producto, nombre_producto, precio_unitario)
VALUES
(1, 'Laptop', 1000.00),
(2, 'Teléfono móvil', 500.00),
(3, 'Tableta', 800.00),
(4, 'Smartwatch', 300.00);

-- Inserción de registros en la tabla Ordenes
INSERT INTO Ordenes (id_orden, fecha_orden, id_cliente)
VALUES
(1, '2022-01-01', 1),
(2, '2022-02-15', 2),
(3, '2022-03-20', 2),
(4, '2022-04-10', 4);

-- Inserción de registros en la tabla DetalleOrden
INSERT INTO DetalleOrden (id_detalle, id_orden, id_producto, cantidad)
VALUES
(1, 1, 1, 2),
(2, 2, 2, 1),
(3, 3, 3, 3),
(4, 4, 2, 2);

-- Queries
select * from clientes;
select * from productos;
select * from ordenes;
select * from detalleOrden;

-- Ejercicios
-- 1.	¿Cuál es la sintaxis correcta para hacer una consulta que muestre 
-- todos los productos junto con su precio unitario?
SELECT nombre_producto, precio_unitario FROM Productos;

-- 2.	¿Cómo se haría para mostrar todas las ordenes realizadas por un cliente específico?
SELECT * FROM Ordenes WHERE id_cliente = 2;

-- 3.	¿Cuál es la sintaxis correcta para hacer una consulta que muestre 
-- la cantidad de veces que un producto ha sido comprado?
SELECT 	id_producto, COUNT(*) AS cantidad_compras
FROM 		DetalleOrden
GROUP BY 	id_producto;


-- 4.	¿Cómo se haría para mostrar todos los productos que nunca han sido comprados?
SELECT 		* 
FROM 		Productos p
LEFT JOIN 	DetalleOrden d 
ON 			p.id_producto = d.id_producto 
WHERE 		d.id_detalle IS NULL;

-- variante con subconsultas
SELECT 	*
FROM 	Productos 
WHERE 	id_producto NOT IN (SELECT id_producto FROM DetalleOrden);


-- 5.	¿Cuál es la sintaxis correcta para hacer una consulta que muestre 
-- el cliente que más ha gastado en la tienda?
SELECT 		c.nombre_cliente, 
			SUM(p.precio_unitario * d.cantidad) as total_gastado
FROM 		Clientes c
INNER JOIN 	Ordenes o ON c.id_cliente = o.id_cliente
INNER JOIN 	DetalleOrden d ON o.id_orden = d.id_orden
INNER JOIN 	Productos p ON d.id_producto = p.id_producto
GROUP BY 	c.id_cliente
ORDER BY 	total_gastado DESC
LIMIT 		1;








