-- selecciono la base por defecto
use pubs;

-- listar el titulo mas caro de 
-- cada categoria
select		type as categoria,
			max(price) 'libro mas caro'
from		titles
group by 	type;

-- listar las ventas por tienda  y por libro
select		stor_id as tienda,
			title_id as libro,
			sum(qty) ventas
from		sales
group by 	stor_id, title_id;

-- listar las ventas por tienda  y por libro
select		stor_name as tienda,
			title as libro,
			sum(qty) ventas
from		sales s
inner join	stores st on s.stor_id = st.stor_id
inner join	titles t on t.title_id = s.title_id
group by 	stor_name, title;


-- listar las ventas por tienda  y por libro
-- solo de aquellos libros cuya venta sea > 40
select		stor_name as tienda,
			title as libro,
			sum(qty) ventas
from		sales s
inner join	stores st on s.stor_id = st.stor_id
inner join	titles t on t.title_id = s.title_id
group by 	stor_name, title
having		sum(qty) > 35
order by	3 desc;








